# SpamWa
```
$ pkg install python
$ pkg install git
$ python3 -m pip install requests
$ git clone https://github.com/krypton-byte/SpamWa
$ cd SpamWa
$ python3 spam.py
```
