# Auto-Root-Exploit
Auto Root Exploit Tool

Author : Nilotpal Biswas<br />
Facebook : https://www.facebook.com/nilotpal.biswas.73<br />
Twitter : https://twitter.com/nilotpalhacker<br />

USAGE    :

           for kernel version 2.6 all
           bash autoroot.sh 2

           for kernel version 3 all
           bash autoroot.sh 3

           for kernel version 4 all
           bash autoroot.sh 4

           for freebsd & openbsd all
           bash autoroot.sh bsd

           for apple macos all
           bash autoroot.sh app

           for kernel 2.6,3,4 bsd & app all
           bash autoroot.sh all

Screenshot 1<br />
![screenshot autoroot](https://user-images.githubusercontent.com/19248178/42459687-d38e77a4-83b9-11e8-86e2-3fc0408eeb3b.png)

Screenshot 2<br />
![2a](https://user-images.githubusercontent.com/19248178/42459741-f2183386-83b9-11e8-8f92-bf786f6ec6ee.png)

All exploits are suggested by "exploit-db.com" and will update according to it.
