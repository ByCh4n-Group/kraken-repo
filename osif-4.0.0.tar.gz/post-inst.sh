#!/bin/bash

[ -d /tmp/python2.7-requests ] && rm -rf /tmp/python2.7-requests
mkdir /tmp/python2.7-requests && cd /tmp/python2.7-requests
wget https://files.pythonhosted.org/packages/0a/00/8cc925deac3a87046a4148d7846b571cf433515872b5430de4cd9dea83cb/requests-2.7.0.tar.gz
tar -xf requests-2.7.0.tar.gz
rm requests-2.7.0.tar.gz && cd requests-2.7.0
./setup.py build
./setup.py install
[ -d /tmp/python2.7-requests ] && rm -rf /tmp/python2.7-requests